ini readme
